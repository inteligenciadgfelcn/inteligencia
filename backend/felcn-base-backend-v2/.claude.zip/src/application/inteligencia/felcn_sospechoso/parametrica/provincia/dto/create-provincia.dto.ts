export class CreateProvinciaDto {}
