export class CreateLocalidadDto {}
