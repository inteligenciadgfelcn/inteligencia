# Arquitectura propuesta, servicios y transacciones por interfaz � Proyecto SUNESIS

Resumen
- Objetivo: transformar la l�gica del monolito WebForms en microservicios con un frontend desacoplado.  
- Entregable: mapa de servicios, contratos HTTP razonables, y la secuencia/transacci�n esperada por cada interfaz `.aspx` detectada en el an�lisis.

1. Principios arquitect�nicos
- Bounded contexts por dominio (Auth, Usuarios, Casos/Asignaci�n, Operativos, Reportes, Ficheros, Lookups).  
- API REST (JSON) para comunicaci�n s�ncrona; eventos (mensajer�a) para procesos as�ncronos y consistencia eventual.  
- Seguridad centralizada: Auth Service (OAuth2/JWT).  
- Evitar transacciones distribuidas; usar SAGA para orquestar operaciones que toquen varios servicios.  
- Datos: cada microservicio su propia BD o esquema; migraci�n desde tablas legadas (Users, ChildMenu, ASIGNACION, SERVICIO, etc.).

2. Lista de servicios (roles y endpoints recomendados)
- API Gateway
  - Funci�n: entrada �nica, routing, rate-limiting, CORS, TLS, validaci�n de JWT.
- Auth Service
  - Responsabilidad: login, refresh, logout, me, authorize, gesti�n de tokens.
  - Endpoints:
    - `POST /api/auth/login` -> {username,password}
    - `POST /api/auth/refresh` -> {refresh_token}
    - `POST /api/auth/logout` -> auth + {refresh_token}
    - `GET /api/auth/me` -> auth
    - `GET /api/auth/authorize?userId=&resource=&action=` -> auth
- User Profile Service
  - Responsabilidad: CRUD perfil, tel�fonos, grados, mapping legacy (NombreApp, TelefonoCel, Gr_Id).
  - Endpoints:
    - `GET /api/users/{id}`
    - `GET /api/users/by-username/{username}`
    - `PUT /api/users/{id}`
- Permissions Service
  - Responsabilidad: mapping ChildMenu ? Permissions, check granular por recurso.
  - Endpoints:
    - `GET /api/permissions/resource/{resource}`
    - `POST /api/permissions/check` -> {userId, resource, action}
- Cases Service (Asignaci�n)
  - Responsabilidad: lectura/gestion de ASIGNACION, b�squeda por usuario.
  - Endpoints:
    - `GET /api/cases?username={username}`
    - `GET /api/cases/{id}`
    - `PUT /api/cases/{id}` (actualizaciones)
- Operatives Service
  - Responsabilidad: operaciones relacionadas a operativos/numero operativo, relaci�n con ASIGNACION/OPERATIVO tables.
  - Endpoints:
    - `GET /api/operatives?nroOperativo={nro}`
    - `POST /api/operatives`
- Services/Servicio Service (registro de servicios)
  - Responsabilidad: l�gica de `SERVICIO` (Verificaservicio, Muestraservicio, Numeropase).
  - Endpoints:
    - `GET /api/servicios/active?usuario={pase}`
    - `POST /api/servicios`
- Reports Service
  - Responsabilidad: generaci�n de reportes (sincron�a/asincron�a), RPT-MN-*.
  - Endpoints:
    - `POST /api/reports/generate` -> devuelve jobId
    - `GET /api/reports/{jobId}/status`
    - `GET /api/reports/{jobId}/download`
- File Service (Attachments)
  - Responsabilidad: recibir ficheros, almacenar en Blob storage, metadatos en DB.
  - Endpoints:
    - `POST /api/files` -> multipart/form-data -> devuelve fileId + URL
    - `GET /api/files/{id}` -> stream
    - `DELETE /api/files/{id}`
- Lookups Service
  - Responsabilidad: Unidades, Distritales, Grados, Grupos, Pa�s, etc.
  - Endpoints: `GET /api/lookups/{type}`

3. Mapeo de datos (tabla legacy ? servicio)
- Users table:
  - Legacy: `Users.Username`, `Users.Usuario`, `Users.NombreApp`, `Users.TelefonoCel`, `Users.Email`, `Gr_Id`.
  - Mapeo:
    - `Users.Username` -> `users.username`
    - `Users.Usuario` -> `users.userCode`
    - `Users.NombreApp` + `Grados.Descripcion` -> `users.displayName`
    - `Users.TelefonoCel` -> `users.phone`
    - `Gr_Id` -> `users.gradeId`
- ChildMenu ? Permissions: `ChildUrl` -> permission.resource; `usuario` -> mapping user/role grants.
- ASIGNACION/OPERATIVO/SERVICIO ? Cases/Operatives/Services services: conservar campos claves `Casos_Id`, `NroCaso`, `NroOperativo`, `Username`, `Uni_Abrev`, `Dis_Descripcion`, `Grp_Id`.

4. Transacciones / secuencias por interfaz (p�gina ? microservicios)
- Login (flujo equivalente a /Login actual)
  1. Frontend: POST `/api/auth/login` {username,password}.  
  2. Auth Service valida credenciales contra Users DB (hash compare).  
  3. Emite `access_token` (JWT) + `refresh_token`.  
  4. Frontend almacena tokens (secure cookie HttpOnly o storage con mitigaciones).  
  5. Frontend llama `GET /api/auth/me` para poblar labels (`lblgrado`, `lblnombres`, `lblcuenta`, `lblnumero`).  
  6. Frontend usa claims o `GET /api/permissions/check` para habilitar vistas/links.

- `Forms\FRM-CA-01.aspx` (Perfil del usuario)
  1. Frontend obtiene token y llama `GET /api/users/by-username/{username}` (User Profile Service).  
  2. User Service devuelve perfil y `gradeId` ? render en UI (`lblgrado`, etc.).  
  3. Para registros relacionados: llamadas a `GET /api/servicios/active?usuario={pase}` y `GET /api/cases?username={username}` seg�n corresponda.

- `Forms\FRM-OP-ING.aspx` / `FRM-OP-UP.aspx` (operativos)
  1. Front: validar permiso (`permissions.check`) para `FRM-OP-ING.aspx`.  
  2. Llamada `GET /api/operatives?username={username}` y `GET /api/cases?username={username}`.  
  3. Mostrar Grid (GridView) con datos obtenidos.  
  4. Acciones de actualizaci�n ? `PUT /api/operatives/{id}` o `PUT /api/cases/{id}`.  
  5. En operaciones que necesitan notificar varios servicios (ej. crear operativo + crear registro de servicio), se usa SAGA: Orchestrator Service lanza pasos y publica eventos (ej. `operative.created`).

- `Forms\ICIA-SERV-01.aspx` y `ICIA-SERV-04.aspx` (servicios / emergencias)
  1. Page_Init: Front llama `GET /api/servicios/active?usuario={pase}` y `GET /api/servicios/emergency?usuario={pase}`.  
  2. Si no hay servicio, redirect (frontend behavior).  
  3. Para reportes o grabaciones: `POST /api/servicios` con payload; Service guarda en DB y publica evento `servicio.created`.

- `Forms\FRM_ING_ENT2.aspx` (upload doc)
  1. Front llama `POST /api/files` con multipart file + metadata.  
  2. File Service guarda blob (S3/Blob) y retorna `fileId` y `url`.  
  3. Front llama `POST /api/cases/{id}/attachments` o `POST /api/files/metadata` para registrar relaci�n en DB.

- Report pages (`RPT-MN-01`, `RPT-MN-02`, `RepFormIcia.aspx`)
  1. Front solicita generaci�n: `POST /api/reports/generate` con filtros (caseId, fechas).  
  2. Reports Service encola job (RabbitMQ/Kafka) y responde jobId.  
  3. Front consulta `GET /api/reports/{jobId}/status` y obtiene URL cuando listo.

5. Consistencia y transacciones
- Lecturas: usar CQRS para separar consultas pesadas de escrituras; caches para lookups.  
- Escrituras multi-servicio: implementar SAGA (orquestada o coreografiada). Ejemplo: crear operativo que implica actualizar `Operatives` + `Cases` + insertar `SERVICIO` ? Orchestrator controla secuencia y compensaciones.  
- Evitar transacciones distribuidas (MS DTC): preferir compensaciones idempotentes.

6. Seguridad y cumplimiento
- Migrar conexiones: mover strings de conexi�n fuera de c�digo (ValoresGlobales) a secret store (KeyVault/Azure/Hashicorp).  
- Hash de contrase�as: Argon2id o bcrypt.  
- Firmar JWT con RS256, JWK endpoint.  
- TLS extremo a extremo, CORS permitido solo para frontend.  
- Auditor�a central para accesos y cambios sensibles.

7. Migraci�n: plan alto nivel por interfaz
- Fase 0: Inventario y mapeo (obtener todas las stored queries en code-behind, identificar tablas usadas).  
- Fase 1: Implementar Auth Service + Users migration + Permissions seeding (ChildMenu ? Permissions).  
- Fase 2: Crear Cases & Operatives & Services services; crear endpoints read-only que apunten a legacy DB (compat layer) para cut-over incremental.  
- Fase 3: Reescribir cada UI page para llamar APIs en lugar de c�digo-behind directo. Empezar por p�ginas no cr�ticas.  
- Fase 4: Switch de sesi�n: deshabilitar OWIN Cookie (o mantener puente) y forzar JWT.  
- Fase 5: Retirar l�gica legacy y limpiar `App_Code` y connectionstrings en c�digo.

8. Observabilidad y operaciones
- Centralizar logs (ELK/EFK), m�tricas (Prometheus), tracing (OpenTelemetry).  
- Health endpoints `/health` por servicio.  
- Deploy en contenedores; orquestador: Kubernetes.  
- Backups y runbooks para rollback.

9. Recomendaciones t�cnicas r�pidas
- Stack sugerido: .NET 7/8 (WebAPI + EF Core), SQL Server, Redis (cache), RabbitMQ/Kafka (event bus), Azure Blob / S3 (files).  
- API contracts: OpenAPI/Swagger obligatorio.  
- Tests automatizados en cada servicio (unit + integration).

10. Siguiente entregable que puedo generar
- Especificaci�n OpenAPI para cada servicio (Auth, Users, Cases, Operatives, Files, Reports).  
- Scripts SQL para migraci�n inicial de `Users` y `ChildMenu`.  
- Plantilla de SAGA orchestrator (puntos de compensaci�n) para la operaci�n de creaci�n de operativo.

---

Si quieres, genero ahora el OpenAPI inicial para el Auth Service y el mapping SQL concreto para `Users` y `ChildMenu` (para poblar `Roles/Permissions`). �Cu�l prefieres primero: OpenAPI Auth o scripts de migraci�n?  