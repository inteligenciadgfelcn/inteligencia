-- public.situacion definition

-- Drop table

-- DROP TABLE public.situacion;

CREATE TABLE public.situacion (
	id_situacion int8 GENERATED ALWAYS AS IDENTITY( INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 1 CACHE 1 NO CYCLE) NOT NULL,
	id_detenido_auxiliar int8 NOT NULL,
	id_situacion_legal int4 NOT NULL,
	nro_resolucion varchar(50) NOT NULL,
	lugar varchar(100) NOT NULL,
	fecha timestamp NOT NULL,
	autoridad varchar(150) NOT NULL,
	fjt varchar(100) NOT NULL,
	upd_inf text NOT NULL,
	fecha_hora_ingreso timestamp NOT NULL,
	usuario varchar(15) NOT NULL,
	CONSTRAINT situacion_pkey PRIMARY KEY (id_situacion)
);


-- public.situacion foreign keys

ALTER TABLE public.situacion ADD CONSTRAINT fk_situacion_detenido_auxiliar FOREIGN KEY (id_detenido_auxiliar) REFERENCES public.detenido_auxiliar(id_detenido_auxiliar) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE public.situacion ADD CONSTRAINT fk_situacion_situacion_legal FOREIGN KEY (id_situacion_legal) REFERENCES parametricas.situacion_legal(id_situacion_legal) ON DELETE CASCADE ON UPDATE CASCADE;



-- public.estado definition

-- Drop table

-- DROP TABLE public.estado;

CREATE TABLE public.estado (
	id_estado int4 GENERATED ALWAYS AS IDENTITY( INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START 1 CACHE 1 NO CYCLE) NOT NULL,
	id_etapa int4 NOT NULL,
	descripcion varchar(40) NOT NULL,
	CONSTRAINT estado_pkey PRIMARY KEY (id_estado)
);


-- public.estado foreign keys

ALTER TABLE public.estado ADD CONSTRAINT fk_estado_etapa FOREIGN KEY (id_etapa) REFERENCES parametricas.etapa(id_etapa) ON UPDATE CASCADE;


-- public.etapa_proceso definition

-- Drop table

-- DROP TABLE public.etapa_proceso;

CREATE TABLE public.etapa_proceso (
	id_etapa_proceso int8 GENERATED ALWAYS AS IDENTITY( INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 1 CACHE 1 NO CYCLE) NOT NULL,
	id_detenido_auxiliar int8 NOT NULL,
	id_estado int4 NOT NULL,
	nro_resolucion varchar(50) NOT NULL,
	lugar varchar(100) NOT NULL,
	fecha timestamp NOT NULL,
	autoridad varchar(150) NOT NULL,
	fjt varchar(100) NOT NULL,
	CONSTRAINT etapa_proceso_pkey PRIMARY KEY (id_etapa_proceso),
	CONSTRAINT fk_etapa_proceso_detenido_auxiliar FOREIGN KEY (id_detenido_auxiliar) REFERENCES public.detenido_auxiliar(id_detenido_auxiliar) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT fk_etapa_proceso_estado FOREIGN KEY (id_estado) REFERENCES public.estado(id_estado) ON UPDATE CASCADE
);


-- public.situacion_bien definition

-- Drop table

-- DROP TABLE public.situacion_bien;

CREATE TABLE public.situacion_bien (
	id_situacion_bien int8 GENERATED ALWAYS AS IDENTITY( INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 1 CACHE 1 NO CYCLE) NOT NULL,
	id_item_bien_secuestrado int8 NOT NULL,
	fecha_requerimiento timestamp NOT NULL,
	fiscal_requerimiento varchar(300) NOT NULL,
	id_calidad_bien int4 NOT NULL,
	fecha_entrega timestamp NOT NULL,
	responsable_entrega varchar(150) NOT NULL,
	responsable_recepcion varchar(150) NOT NULL,
	institucion varchar(150) NOT NULL,
	ubicacion varchar(150) NOT NULL,
	fecha_hora_ingreso timestamp NOT NULL,
	usuario varchar(15) NOT NULL,
	CONSTRAINT situacion_bien_pkey PRIMARY KEY (id_situacion_bien)
);


-- public.situacion_bien foreign keys

ALTER TABLE public.situacion_bien ADD CONSTRAINT fk_situacion_bien_calidad_bien FOREIGN KEY (id_calidad_bien) REFERENCES parametricas.calidad_bien(id_calidad_bien) ON UPDATE CASCADE;
ALTER TABLE public.situacion_bien ADD CONSTRAINT fk_situacion_bien_item_bien_secuestrado FOREIGN KEY (id_item_bien_secuestrado) REFERENCES public.item_bien_secuestrado(id_item_bien_secuestrado) ON DELETE CASCADE ON UPDATE CASCADE;


-- public.archivo_bien definition

-- Drop table

-- DROP TABLE public.archivo_bien;

CREATE TABLE public.archivo_bien (
	id_archivo_bien int8 GENERATED ALWAYS AS IDENTITY( INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 1 CACHE 1 NO CYCLE) NOT NULL,
	id_caso int8 NOT NULL,
	id_contenido_bien int8 NOT NULL,
	tipo varchar(15) NOT NULL,
	nombre varchar(150) NOT NULL,
	nombre_archivo varchar(150) NOT NULL,
	"data" bytea NOT NULL,
	CONSTRAINT archivo_bien_pkey PRIMARY KEY (id_archivo_bien)
);


-- public.archivo_bien foreign keys

ALTER TABLE public.archivo_bien ADD CONSTRAINT fk_archivo_bien_asignacion FOREIGN KEY (id_caso) REFERENCES public.asignacion(id_caso);